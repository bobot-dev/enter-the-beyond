﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NpcApi
{
    class SimplerShopSetupDoer
    {
        //ill get to it when i can be bothered :)
    }
}
