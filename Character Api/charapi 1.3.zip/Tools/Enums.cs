﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CustomCharacters
{
    class Enums
    {
		//quickstart is shit god i fucking hate this so much :))))
		public enum QuickstartCharacter
		{

			LAST_USED,

			PILOT,

			CONVICT,

			SOLDIER,

			GUIDE,

			BULLET,

			ROBOT,

			LOST

		}
	}
}
