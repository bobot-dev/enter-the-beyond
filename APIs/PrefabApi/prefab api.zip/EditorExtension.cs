﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrefabAPI
{
    public abstract class EditorExtension : EditorObject
    {
        public EditorExtension()
        {
        }
    }
}
